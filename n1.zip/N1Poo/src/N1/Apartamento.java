package N1;

public class Apartamento extends Imovel implements Manutencao {

    private int andar;

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }

    @Override
    public double calcularTaxaManutencao() {
        return getTamanho() * 2 + andar * 10; 
    }
}
