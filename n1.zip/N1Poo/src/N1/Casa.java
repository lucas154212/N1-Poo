package N1;

public class Casa extends Imovel implements Manutencao {

    private int numeroDeQuartos;

    public int getNumeroDeQuartos() {
        return numeroDeQuartos;
    }

    public void setNumeroDeQuartos(int numeroDeQuartos) {
        this.numeroDeQuartos = numeroDeQuartos;
    }

    @Override
    public double calcularTaxaManutencao() {
        return getTamanho() * 1.5 + numeroDeQuartos * 20; 
    }
}
